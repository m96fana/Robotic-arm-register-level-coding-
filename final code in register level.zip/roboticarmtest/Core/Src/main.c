/*
 * This version replaces HAL functions with direct register access.
 * Now includes EXTI interrupt handling for PB12–PB15 buttons.
 */


#include "main.h"
#include "string.h"
#include <stdio.h>

volatile uint16_t pulse[4] = {500, 500, 500, 500};

void delay_ms(uint32_t ms) {
    for (uint32_t i = 0; i < ms * 8000; i++) __asm("NOP");
}

void GPIO_Config(void) {
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPAEN | RCC_APB2ENR_AFIOEN;

    // PB12–PB15 input with pull-up (EXTI)
    GPIOB->CRH &= ~(GPIO_CRH_MODE12 | GPIO_CRH_CNF12 |
                    GPIO_CRH_MODE13 | GPIO_CRH_CNF13 |
                    GPIO_CRH_MODE14 | GPIO_CRH_CNF14 |
                    GPIO_CRH_MODE15 | GPIO_CRH_CNF15);
    GPIOB->CRH |= (0x8 << (4 * (12 - 8))) | (0x8 << (4 * (13 - 8))) |
                  (0x8 << (4 * (14 - 8))) | (0x8 << (4 * (15 - 8)));
    GPIOB->ODR |= GPIO_ODR_ODR12 | GPIO_ODR_ODR13 | GPIO_ODR_ODR14 | GPIO_ODR_ODR15;

    // Map PB12–PB15 to EXTI12–15
    AFIO->EXTICR[3] &= ~0xFFFF;
    AFIO->EXTICR[3] |= 0x1111;  // PB for EXTI12–15

    EXTI->IMR |= EXTI_IMR_MR12 | EXTI_IMR_MR13 | EXTI_IMR_MR14 | EXTI_IMR_MR15;
    EXTI->FTSR |= EXTI_FTSR_TR12 | EXTI_FTSR_TR13 | EXTI_FTSR_TR14 | EXTI_FTSR_TR15;

    NVIC_EnableIRQ(EXTI15_10_IRQn);

    // PA0–PA1 TIM2 PWM, PA8–PA9 TIM1 PWM
    GPIOA->CRL &= ~(GPIO_CRL_MODE0 | GPIO_CRL_CNF0 | GPIO_CRL_MODE1 | GPIO_CRL_CNF1);
    GPIOA->CRL |=  (0b10 << GPIO_CRL_MODE0_Pos) | (0b10 << GPIO_CRL_CNF0_Pos);
    GPIOA->CRL |=  (0b10 << GPIO_CRL_MODE1_Pos) | (0b10 << GPIO_CRL_CNF1_Pos);

    GPIOA->CRH &= ~(GPIO_CRH_MODE8 | GPIO_CRH_CNF8 | GPIO_CRH_MODE9 | GPIO_CRH_CNF9);
    GPIOA->CRH |=  (0b10 << GPIO_CRH_MODE8_Pos) | (0b10 << GPIO_CRH_CNF8_Pos);
    GPIOA->CRH |=  (0b10 << GPIO_CRH_MODE9_Pos) | (0b10 << GPIO_CRH_CNF9_Pos);
}

void TIM2_PWM_Init(void) {
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    TIM2->PSC = 72;
    TIM2->ARR = 20000;
    TIM2->CCMR1 |= (6 << 4) | (6 << 12);
    TIM2->CCER |= TIM_CCER_CC1E | TIM_CCER_CC2E;
    TIM2->CR1 |= TIM_CR1_CEN;
}

void TIM1_PWM_Init(void) {
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
    TIM1->PSC = 72;
    TIM1->ARR = 20000;
    TIM1->CCMR1 |= (6 << 4) | (6 << 12);
    TIM1->CCER |= TIM_CCER_CC1E | TIM_CCER_CC2E;
    TIM1->BDTR |= TIM_BDTR_MOE;
    TIM1->CR1 |= TIM_CR1_CEN;
}

void RCC_Config(void) {
    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY));
    FLASH->ACR |= FLASH_ACR_PRFTBE;
    FLASH->ACR |= FLASH_ACR_LATENCY_2;
    RCC->CFGR |= RCC_CFGR_PLLSRC | RCC_CFGR_PLLMULL9;
    RCC->CFGR |= RCC_CFGR_PPRE1_DIV2;
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);
}

void update_pwm(void) {
    if (pulse[0] > 2500) pulse[0] = 2500;
    if (pulse[0] < 500)  pulse[0] = 500;
    if (pulse[1] > 2500) pulse[1] = 2500;
    if (pulse[1] < 500)  pulse[1] = 500;
    TIM2->CCR2 = pulse[0];
    TIM2->CCR1 = pulse[1];
    TIM1->CCR2 = pulse[2];
    TIM1->CCR1 = pulse[3];
}

void EXTI15_10_IRQHandler(void) {
    if (EXTI->PR & EXTI_PR_PR12) {
        pulse[0] += 333;
        EXTI->PR = EXTI_PR_PR12;
    }
    if (EXTI->PR & EXTI_PR_PR13) {
        pulse[1] += 333;
        EXTI->PR = EXTI_PR_PR13;
    }
    if (EXTI->PR & EXTI_PR_PR14) {
        pulse[0] -= 333;
        EXTI->PR = EXTI_PR_PR14;
    }
    if (EXTI->PR & EXTI_PR_PR15) {
        pulse[1] -= 333;
        EXTI->PR = EXTI_PR_PR15;
    }
    update_pwm();
}

int main(void) {
    RCC_Config();
    GPIO_Config();
    TIM2_PWM_Init();
    TIM1_PWM_Init();
    while (1) {
        delay_ms(100);
    }
}
